# 舞台流程管理系统 - 多角色权限升级计划

## 概述

将现有单文件舞台流程表升级为局域网多角色协作系统。通过 URL 参数区分三种角色（控制端/舞台助理端/幕后端），各自拥有不同权限。同时增加 PDF/Word 导入、删除计时器、三按钮导航（上一个/Go/下一个）、节目状态三态显示（已完成划线/进行中高亮/未开始）、重置功能，并将时间显示移入节目卡片。

---

## 现状分析

### 当前文件结构
- `/workspace/舞台流程表.html` — 单文件 HTML+CSS+JS（约 1860 行），内联 SortableJS/QRCode，CDN 引入 html2pdf/file-saver
- `/workspace/server.js` — Node.js HTTP + WebSocket 服务器（端口 3000），状态持久化到 `show.json`
- `/workspace/show.json` — 当前状态数据

### 当前数据模型
```
localState = {
  showName, mode, currentProgramIndex,
  globalChannels: { mics:[], lines:[] },
  programs: [{ name, duration(秒), notes, musicCue, completed(bool), useChannels:[] }]
}
timerInfo = { remaining, running, finished }
```

### 当前计时器 UI（需替换）
- 第 836-844 行：`.timer-section`（计时器显示 + 开始/暂停/重置三按钮）
- 第 847-849 行：`.advance-section`（标记完成并进入下一节目按钮）

### 关键约束
- Safari 14 兼容（不支持 `??=`/`||=`/顶层 await/`#私有字段`/`Array.at()`/`Object.hasOwn()`/`structuredClone()`/`String.replaceAll()`；`backdrop-filter` 需 `-webkit-` 前缀）
- 单文件架构：业务代码内联，大型第三方库用 CDN defer（离线降级）
- Apple 风格 UI 保持

---

## 数据模型变更

### 1. 时长单位：秒 → 分钟
- `program.duration` 从秒改为分钟存储（如 5 = 5 分钟）
- 迁移策略：`mergeState` 内检测旧值，若 `duration >= 60` 则 `Math.round(oldDuration / 60)`；引入 `state.version = 3` 标记

### 2. 节目状态三态（新增 `status` 字段）
```
program.status: 'pending' | 'active' | 'completed'
```
- `pending`：未开始（默认）
- `active`：进行中（当前节目，由导航操作触发）
- `completed`：已完成（整条划线）
- 迁移：`completed===true` → `status='completed'`，否则 `status='pending'`

### 3. 移除计时器相关数据
- 删除前端 `timerInfo`、`localTimerInterval` 及所有计时器变量
- 服务端删除 `timer` 对象与 `timerInterval`

---

## 角色权限矩阵

| 能力 | control | assistant | backstage |
|---|---|---|---|
| 模式切换（setup/performance） | 是 | 否 | 否 |
| 添加/删除节目、拖拽排序 | 是 | 否 | 否 |
| 编辑节目名称、时长 | 是 | 否 | 否 |
| 编辑音乐节点 musicCue | 是 | 是 | 否 |
| 选择/取消通道 useChannels | 是 | 是 | 否 |
| 编辑备注 notes | 是 | 是 | 是 |
| 通道增减（全局通道配置） | 是 | 否 | 否 |
| 导入 PDF/Word | 是 | 否 | 否 |
| 三按钮导航（上一个/Go/下一个） | 是 | 否（只读） | 否（只读） |
| 重置（全部/单个） | 是 | 否 | 否 |
| 导出 PDF/CSV、二维码、改名 | 是 | 否 | 否 |
| 查看节目单 + 实时同步 | 是 | 是 | 是 |

**架构决策**：前端为主控制（按 role 显隐/禁用 UI），服务端为兜底校验（写操作校验 role）。局域网信任环境下不引入 token 鉴权，保持简单。

---

## 实施变更

### 变更 1：server.js 改造

**文件**：`/workspace/server.js`

**修改内容**：
1. 删除计时器全部代码（`timer` 对象、`timerInterval`、`currentDuration`、`resetTimerToCurrent`、`startTimer`、`stopTimer`、`tick`、`broadcastTimer`、timer 相关 case）
2. `defaultState` 补齐 `globalChannels` 与 `version: 3`
3. 新增消息类型与角色校验：
   - `advance`（Go 按钮）：当前节目 → completed，index+1，新节目 → active
   - `prev`：index-1，新节目 → active
   - `next`：index+1，新节目 → active
   - `reset_all`：所有节目 status → pending，currentProgramIndex → 0
   - `reset_one`：指定节目 status → pending
   - `update_program_field`：分级字段更新（idx, field, value, role），服务端校验 role 对 field 的权限
   - `import_programs`：合并或替换 programs（仅 control）
4. 改造 `update_state`：仅 control 可整体更新
5. 新增 `sendError(ws, code)` 越权返回 `{ type:'error', code:'forbidden' }`
6. `full_state` 广播移除 `timer` 字段

### 变更 2：删除计时器 UI 与逻辑

**文件**：`/workspace/舞台流程表.html`

**修改内容**：
- HTML：删除第 836-844 行 `.timer-section` 整块
- CSS：删除 `.timer-section`/`.timer-display`/`.timer-controls`/`.btn-timer`/`.timer-finished` 样式（第 252-284 行等）
- JS：删除 `timerInfo`、`localTimerInterval`、`currentDuration`、`resetLocalTimer`、`startLocalTimer`、`stopLocalTimer`（第 1142-1185 行）、`renderTimer`（第 1550-1556 行）、`timerControl`（第 1568-1576 行）
- JS：`handleLocalMessage` 删除 timer 分支（第 1127-1138 行）
- JS：WebSocket `onmessage` 删除 `case "timer"`（第 1010-1016 行）
- JS：`full_state` 处理移除 `data.timer`（第 1007 行）

### 变更 3：三按钮导航（替换 advance-section）

**文件**：`/workspace/舞台流程表.html`

**HTML**（替换第 847-849 行）：
```html
<div class="nav-controls" id="nav-controls">
  <button class="nav-btn nav-small" id="btn-prev" onclick="navProgram('prev')">◀ 上一个</button>
  <button class="nav-btn nav-go" id="btn-go" onclick="navProgram('go')">GO</button>
  <button class="nav-btn nav-small" id="btn-next" onclick="navProgram('next')">下一个 ▶</button>
</div>
<div class="reset-bar" id="reset-bar">
  <button class="btn btn-secondary btn-sm" onclick="resetProgram('all')">↺ 重置全部</button>
</div>
```

**CSS**：
```css
.nav-controls {
  display:flex; align-items:center; justify-content:space-between;
  gap:16px; margin-top:16px;
  padding-bottom: calc(16px + env(safe-area-inset-bottom));
}
.nav-btn { border-radius:14px; border:1px solid var(--stroke); cursor:pointer;
  background:rgba(44,44,46,0.66); -webkit-backdrop-filter:blur(10px); backdrop-filter:blur(10px);
  color:#fff; transition: transform .12s ease, background .2s ease; }
.nav-small { padding:14px 18px; font-size:15px; min-height:56px; min-width:120px; }
.nav-go {
  flex:0 0 auto; padding:0 56px; font-size:26px; font-weight:700;
  min-height:112px; min-width:200px;
  background:var(--ios-green); border-color:rgba(48,209,88,0.5);
  box-shadow:0 4px 24px rgba(48,209,88,0.35); letter-spacing:2px;
}
.nav-go:active { transform:scale(0.96); }
.reset-bar { text-align:center; margin-top:10px; }
```

**JS**：
```javascript
window.navProgram = function(act){
  if(!can('nav')) return;
  if(act==='go') sendMsg({type:'advance', role:ROLE});
  else if(act==='prev') sendMsg({type:'prev', role:ROLE});
  else if(act==='next') sendMsg({type:'next', role:ROLE});
};
window.resetProgram = function(scope, idx){
  if(!can('reset')) return;
  if(scope==='all') sendMsg({type:'reset_all', role:ROLE});
  else sendMsg({type:'reset_one', idx:idx, role:ROLE});
};
```

### 变更 4：时长显示移入节目卡片

**文件**：`/workspace/舞台流程表.html`

- 当前节目卡（第 818-825 行）内增加 `<div id="current-duration" class="card-duration"></div>`
- 节目列表项右侧时长从 `formatSec(prog.duration)` 改为 `formatDuration(prog.duration)`（分钟格式）
- 新增分钟格式化函数：
```javascript
function formatDuration(min){
  min = Math.max(0, Math.floor(Number(min)||0));
  if(min<=0) return "无时长";
  var h = Math.floor(min/60), m = min%60;
  if(h>0 && m>0) return h+"小时"+m+"分";
  if(h>0) return h+"小时";
  return m+"分钟";
}
```

### 变更 5：节目状态三态视觉

**文件**：`/workspace/舞台流程表.html`

**CSS**：
```css
.program-item.is-completed .prog-name,
.program-item.is-completed .prog-meta { text-decoration:line-through; opacity:0.55; }
.program-item.is-active {
  border-color:var(--ios-green);
  background:rgba(48,209,88,0.10);
  box-shadow:0 2px 16px rgba(48,209,88,0.20);
}
```

**JS**：`renderProgramList` 中按 `deriveStatus(prog, idx)` 添加 class：
```javascript
function deriveStatus(prog, idx){
  if(prog.status==='completed') return 'is-completed';
  if(idx===localState.currentProgramIndex && prog.status==='active') return 'is-active';
  return '';
}
```

### 变更 6：角色权限系统

**文件**：`/workspace/舞台流程表.html`

**JS**（新增，紧跟 `localState` 声明后）：
```javascript
function getRole(){
  var p = new URLSearchParams(location.search);
  var r = p.get('role');
  return ['control','assistant','backstage'].indexOf(r)>=0 ? r : 'control';
}
var ROLE = getRole();
var PERM = {
  control:    { mode:true, addDel:true, drag:true, editName:true, editDuration:true,
                editMusic:true, editChannel:true, editNotes:true, channelAdmin:true,
                import:true, nav:true, reset:true, exportIt:true, rename:true },
  assistant:  { editMusic:true, editChannel:true, editNotes:true },
  backstage:  { editNotes:true }
};
function can(k){ return !!(PERM[ROLE] && PERM[ROLE][k]); }
```

**UI 按角色过滤**：
- 非 control 角色隐藏：模式切换、添加节目、全局通道、导出、改名、导入按钮
- 非 control 强制 performance 模式，隐藏设置视图
- 仅 control 显示导航按钮与重置按钮
- 顶部增加角色徽章（控制端/助理端/幕后端）

**就地编辑**（assistant/backstage）：
- 点击节目卡片进入就地编辑视图（复用 `#edit-panel`）
- 按 role 禁用不允许的字段
- 分级字段更新：`updateProgramField(idx, field, value)` → `sendMsg({type:'update_program_field', ...})`

### 变更 7：QR 码支持多角色链接

**文件**：`/workspace/舞台流程表.html`

- QR 码弹窗显示三个角色链接（control/assistant/backstage），各自可扫码访问
- 各链接基于当前页面 URL + `?role=xxx` 参数

### 变更 8：PDF/Word 导入功能

**文件**：`/workspace/舞台流程表.html`

**CDN 引入**（第 13-14 行附近）：
```html
<script defer src="https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/legacy/build/pdf.min.js"></script>
<script defer src="https://cdn.jsdelivr.net/npm/mammoth@1.6.0/mammoth.browser.min.js"></script>
```
- PDF.js 使用 **legacy build** 兼容 Safari 14
- 离线/加载失败时导入按钮提示"需联网加载解析库"

**导入弹窗** `#modal-import`：
- 文件选择（accept `.pdf,.docx`）+ 拖拽区
- 解析预览列表（可勾选/编辑名称/时长）
- "追加到末尾"或"替换全部"单选
- 确认按钮

**解析逻辑**：
```javascript
async function parseImportFile(file){
  var name = file.name.toLowerCase();
  if(name.endsWith('.pdf')){
    pdfjsLib.GlobalWorkerOptions.workerSrc =
      'https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/legacy/build/pdf.worker.min.js';
    var buf = await file.arrayBuffer();
    var pdf = await pdfjsLib.getDocument({data:buf}).promise;
    var text = '';
    for(var p=1;p<=pdf.numPages;p++){
      var c = await pdf.getPage(p); var t = await c.getTextContent();
      text += t.items.map(function(it){return it.str;}).join(' ')+'\n';
    }
    return text;
  }
  if(name.endsWith('.docx')){
    var buf2 = await file.arrayBuffer();
    var r = await mammoth.extractRawText({arrayBuffer:buf2});
    return r.value;
  }
  throw new Error('仅支持 PDF 与 DOCX');
}
```

**节目识别规则**（`textToPrograms`）：
- 行首序号：`1.` / `1、` / `（1）` / `第一` / `节目一`
- 行内时长：`5分` / `5分钟` / `5'` / `00:05` / `5:00`
- 识别后映射为 `{ name, duration(分钟), notes, musicCue, status:'pending', useChannels:[] }`
- 未识别为节目的行作为上一节目的 notes 追加

### 变更 9：`mergeState` 迁移升级

**文件**：`/workspace/舞台流程表.html`（第 1047-1067 行）

- 加入 `version` 检测：v2→v3 时 `duration` 秒转分钟、`completed`→`status`
- `programs.map` 内补 `status` 字段（默认 `'pending'`）
- 保留对旧 `musicNode` 字段的合并（已有 `mergeMusicField`）

---

## 假设与决策

1. **Go 按钮行为**：Go = 标记当前节目为已完成并前进到下一节目（等同原 `advanceProgram` 逻辑，但在服务端原子处理，避免多端竞态）
2. **"进行中"定义**：`currentProgramIndex` 指向且 `status='active'` 的节目为"进行中"
3. **角色安全**：纯前端权限可被绕过（改 URL 参数即可升权），服务端 role 校验为兜底。局域网信任环境下不引入 token 鉴权
4. **时长迁移精度**：秒→分钟可能产生 1 分钟误差，迁移仅执行一次，建议迁移前人工核对
5. **PDF.js 体积**：legacy build 约 1MB+，CDN defer 不阻塞首屏；断网时导入不可用（可接受，导入属离线准备阶段）
6. **节目识别准确率**：纯文本正则无法覆盖所有格式，强制提供预览编辑步骤

---

## 验证步骤

1. **多设备同步**：control 端 Go/上一个/下一个/重置 → assistant/backstage 实时收到 `full_state` 更新
2. **权限边界**：
   - backstage 改备注成功；改音乐节点被服务端拒绝并前端 toast
   - assistant 改通道成功、改节目名被拒
3. **数据迁移**：用旧 `show.json`（秒制 + completed 布尔）启动，验证自动转分钟 + status，节目数据无丢失
4. **导入**：PDF 与 DOCX 各一例，验证节目识别；拖拽上传；离线断网时导入按钮降级提示
5. **状态视觉**：已完成整条划线、进行中绿色高亮、未开始默认态；重置全部后全部回到 pending
6. **Safari 14 兼容**：backdrop-filter、PDF.js legacy worker、`URLSearchParams`、`file.arrayBuffer`
7. **单文件完整性**：业务代码内联，仅第三方库 CDN；断网时核心查看/编辑/同步仍可用
8. **局域网访问**：`http://<本机IP>:3000/?role=control`、`?role=assistant`、`?role=backstage` 三链接分别验证

---

## 实施顺序（依赖排序）

1. 数据迁移先行：升级 `mergeState`（前后端）支持 `version`/`status`/分钟
2. server.js 改造：删计时器、新增消息类型与 role 校验、补 `defaultState`
3. 删除前端计时器链路：移除 `timerInfo`/渲染/控制/本地 interval
4. 时长单位切换：`formatDuration` 替换 `formatSec`
5. 三按钮导航：新增 HTML/CSS + `navProgram` + 服务端 advance/prev/next
6. 节目状态三态与重置：`deriveStatus` + CSS 样式 + 重置全部/单个
7. 角色权限系统：`getRole`/`PERM`/`can` + `applyRoleVisibility` + 各入口拦截
8. 就地编辑（assistant/backstage）：分级字段更新 + 服务端校验
9. 导入功能：引入 PDF.js/mammoth.js、`parseImportFile`、`textToPrograms`、预览弹窗
10. 头部与角色徽章：按 role 显隐按钮、显示角色标识、QR 码多角色链接
11. 回归与兼容测试
