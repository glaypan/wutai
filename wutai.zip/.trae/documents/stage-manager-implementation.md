# 舞台流程表 Web 应用 - 实现计划

## 概述

基于需求文档 `bh.txt` 和 SHOWLIST PRO 参考图片，构建一个基于 WebSocket 实时同步的舞台流程表 Web 应用。支持设置/演出双模式切换、节目管理、话筒启用状态管理、倒计时器、多客户端协同、`show.json` 持久化。整体采用暗黑舞台主题。

## 当前状态分析

### 已有资料
- **需求文档** (`bh.txt`)：提供完整前端三件套代码（`index.html`、`style.css`、`app.js`），定义了 WebSocket 消息协议，但缺少 `server.js`。
- **参考图片** (7张)：展示 SHOWLIST PRO 舞台助理系统的暗色主题界面，含节目序号徽章、当前/下一节目双卡布局、话筒彩色标签、绿色"正在进行"标识、拖拽排序等视觉参考。

### 需求文档中的前端缺陷（必须修复）
1. `index.html` 第97行 `<h3>编辑演出名称</h3` 标签未闭合
2. `app.js` 中 `addMicRow('add')` 因 `editingIndex === null` 判断失效，添加弹窗无法新增话筒
3. `confirmAddProgram` 硬编码话筒，忽略添加弹窗配置
4. `#edit-show-name-btn` 编辑演出名称按钮无事件绑定
5. `openAddProgram` 未初始化话筒列表渲染
6. 缺少 `client-count` 客户端连接数渲染逻辑

### 技术架构
```
浏览器(多端)  ←─WebSocket─→  Node.js 服务进程
   │                            │
   ├─ index.html                ├─ HTTP 静态服务 (public/)
   ├─ style.css                 ├─ WebSocket 服务 (ws)
   ├─ app.js                    ├─ 状态管理 (内存)
   └─ qrcode.min.js             ├─ 计时器 (1s tick)
                                └─ show.json 持久化 (fs)
```
单进程同时承载 HTTP 静态文件服务和 WebSocket 服务，复用同一端口（默认 3000），适合局域网离线部署。

## 数据模型

**show.json（持久化结构状态）：**
```json
{
  "showName": "舞台流程表",
  "mode": "setup",
  "currentProgramIndex": 0,
  "programs": [
    {
      "name": "节目名称",
      "duration": 300,
      "notes": "备注",
      "completed": false,
      "mics": [
        {"name": "麦1", "active": true},
        {"name": "麦2", "active": false}
      ]
    }
  ]
}
```

**计时器状态（内存，不落盘，每秒广播）：**
```json
{ "remaining": 300, "running": false, "duration": 300, "finished": false }
```

设计决策：结构状态写 `show.json`；计时器为高频 ephemeral 状态，仅内存维护并广播，避免每秒写盘。

## WebSocket 协议规范

| 方向 | type | 字段 | 说明 |
|:---|:---|:---|:---|
| C→S | `get_state` | - | 请求完整快照 |
| C→S | `update_state` | `data:{...}` | 浅合并更新状态字段 |
| C→S | `set_current` | `index:Number` | 设置当前节目索引，自动重置计时器 |
| C→S | `timer_start` | `duration:Number` | 启动倒计时 |
| C→S | `timer_stop`/`stop` | - | 暂停计时 |
| C→S | `timer_reset`/`reset` | - | 重置为当前节目时长 |
| S→C | `full_state` | `state`, `timer`, `clientCount` | 完整快照 |
| S→C | `timer` | `remaining`, `running`, `finished` | 计时器反馈 |
| S→C | `client_count` | `count` | 在线客户端数量 |

## 实施步骤

### 步骤 1：创建项目结构和 `package.json`
- **文件**：`/workspace/package.json`
- **内容**：依赖 `ws@^8.18.0`，scripts.start = `node server.js`
- **原因**：项目唯一外部依赖是 WebSocket 库

### 步骤 2：创建 `server.js`
- **文件**：`/workspace/server.js`
- **内容**：Node.js HTTP + WebSocket 服务器，包含：
  - 静态文件服务（`public/` 目录，含 MIME 映射、路径穿越防护）
  - 状态加载/保存（`show.json` 读写，启动时加载、变更时保存）
  - 计时器管理（start/stop/reset/tick，每秒广播）
  - WebSocket 消息处理（上述协议全部 type）
  - 广播函数（full_state / timer / client_count）
  - 边界修正（currentProgramIndex 越界 clamp）
- **原因**：需求文档未提供 server.js，需根据前端 app.js 的消息协议推断实现

### 步骤 3：创建 `public/index.html`
- **文件**：`/workspace/public/index.html`
- **内容**：以需求文档代码为基础，修复+增强：
  - 修复 `<h3>` 标签闭合
  - 当前节目卡增加总时长显示元素 `#current-total`
  - 演出视图增加"标记完成并进入下一节目"按钮
  - 引入 `qrcode.min.js`
- **原因**：需求文档 HTML 有标签缺陷，且缺少几个增强元素

### 步骤 4：创建 `public/style.css`
- **文件**：`/workspace/public/style.css`
- **内容**：需求文档完整 CSS + 追加样式：
  - 节目序号徽章 `.prog-no`（参考 SHOWLIST PRO 圆形序号）
  - "正在进行"绿色标识
  - 当前节目总时长样式
  - 标记完成按钮样式
  - 客户端连接数样式
  - 计时器状态色（running 绿色 / finished 红色）
- **原因**：补充增强元素所需样式，视觉上更接近参考图片

### 步骤 5：创建 `public/app.js`
- **文件**：`/workspace/public/app.js`
- **内容**：需求文档 app.js 的修复+增强版，关键改动：
  - 引入 `addMics` 临时数组 + `renderAddMicList()` 修复添加弹窗话筒功能
  - `addMicRow(target)` 支持 `'add'` 参数操作 addMics
  - `confirmAddProgram` 使用 addMics 而非硬编码
  - 绑定 `#edit-show-name-btn` 点击事件
  - `openAddProgram` 初始化话筒列表渲染
  - 新增 `updateClientCount(n)` 渲染连接数
  - 新增 `advanceProgram()` 标记完成并进入下一节目
  - `showQR()` 使用 QRCode 库生成二维码，降级显示 URL
  - `deleteProgram` 修正 currentProgramIndex
  - 新增 `escapeHtml`/`escapeAttr` 防 XSS
- **原因**：修复需求文档中的6处缺陷，并添加增强功能

### 步骤 6：创建 `public/qrcode.min.js`（可选）
- **文件**：`/workspace/public/qrcode.min.js`
- **内容**：vendored qrcodejs 库（davidshimjs/qrcodejs，MIT）
- **原因**：离线二维码生成，缺失时降级显示 URL 文本

### 步骤 7：安装依赖并验证
- 执行 `npm install`
- 执行 `npm start` 启动服务
- 浏览器访问 `http://localhost:3000` 验证功能

## 假设与决策

1. **server.js 需自行创建**：需求文档明确说"server.js 不需要改动"，但未提供其代码。根据 app.js 的 WebSocket 消息类型推断完整服务端实现。
2. **计时器不落盘**：仅结构状态（节目/模式/索引）写入 show.json，计时器为内存 ephemeral 状态，避免每秒写盘。
3. **服务端为唯一时间源**：计时器以服务端 setInterval 为准，客户端仅展示服务端广播的 remaining，不本地递减，避免多端漂移。
4. **协议命名兼容**：服务端同时接受 `timer_stop`/`stop`、`timer_reset`/`reset`，保证鲁棒性。
5. **QR 码库降级**：若 qrcode.min.js 缺失，二维码区域降级显示 URL 文本，不影响核心功能。
6. **前端代码以需求文档为基础**：不重写设计，仅修复缺陷+小幅增强，保持与需求文档一致性。
7. **端口默认 3000**：可通过 `PORT` 环境变量覆盖。

## 验证步骤

- [ ] 顶部单一按钮切换设置/演出模式，颜色自动变化（灰→蓝）
- [ ] 新增节目自带话筒，默认启用；添加弹窗话筒增删正常
- [ ] 编辑节目可新增/删除话筒，点击启用/关闭切换 active 状态
- [ ] 节目列表永久展示所有话筒；演出面板仅渲染 active 话筒
- [ ] 切换节目自动重置计时器为新节目时长
- [ ] 计时器开始/暂停/重置跨多端实时同步，到点显示"时间到"
- [ ] "标记完成并进入下一节目"：当前节目变灰、索引前进、计时器重置
- [ ] 演出名称编辑、QR 扫码访问、客户端连接数显示
- [ ] 全部状态自动保存 show.json，刷新页面/重启服务不丢失话筒开关
- [ ] 多端打开，任一端操作其余端实时同步
- [ ] 蓝色=激活、深灰=关闭、绿色=正在进行、完成节目降低透明度，色彩统一

## 目录结构（最终输出）

```
/workspace/
├── server.js              # Node.js WebSocket + HTTP 服务器
├── package.json           # 依赖声明
├── show.json              # 运行时自动生成
└── public/
    ├── index.html         # 主页面
    ├── style.css          # 样式
    ├── app.js             # 前端逻辑
    └── qrcode.min.js      # 二维码生成库（可选）
```
