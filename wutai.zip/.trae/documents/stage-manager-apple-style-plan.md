# 舞台流程表 Apple 风格优化 + 功能增强方案

## 概述

对 `/workspace/舞台流程表.html`（单文件应用，约 1460 行，内联 CSS/JS/QRCode 库）进行 8 项改造：合并音乐字段、自定义类型输入、舞台视图通道类型标签、演出模式详情弹窗、Apple Liquid Glass 设计、跨平台一键运行、Safari 14 兼容、iPad/iPhone 适配。所有改动集中在单文件内，双击即可在任意 OS 浏览器离线运行。

## 当前状态分析

- 单 HTML 文件，已内联 QRCode 库；html2pdf / file-saver / SortableJS 走 CDN
- 字体已用 `-apple-system, BlinkMacSystemFont`，但无玻璃效果、无 iOS 色系变量
- 有两个音乐字段：`musicNode`（精准切入节点）和 `musicCue`（简易提示），造成 UI 冗余
- 通道类型下拉选"自定义"后无法填写自定义名称（无 `customType` 字段）
- 演出模式舞台卡通道标签只显示通道名，不显示类型
- 演出模式点击节目仅切换当前节目，无法查看详情
- `mergeState()` 负责旧数据兼容迁移
- 启动时先尝试 WebSocket，3 秒后才降级到 localStorage（离线场景体验差）
- flexbox `gap` 属性广泛使用（约 18 处），Safari 14.0 不支持
- `.modal` 使用 `inset:0`，Safari 14.0 不支持
- 无 `backdrop-filter` 玻璃效果
- 响应式仅单一 768px 断点

## 关键兼容性事实（已核实）

- flexbox `gap` 在 Safari 14.0 不被解析，14.1 才支持 [$TRAE_REF](https://developer.apple.com/documentation/safari-release-notes/safari-14_1-release-notes)[$TRAE_REF](https://m.php.cn/faq/2749164.html)
- `inset` 简写在 Safari 14.0 不支持，14.1 才支持 → 展开为 `top/right/bottom/left`
- `backdrop-filter` 在 Safari 9+ 需 `-webkit-` 前缀 [$TRAE_REF](https://m.php.cn/faq/2865297.html)
- macOS 10.14.6 Mojave 可获得 Safari 14.0
- Liquid Glass 核心 = `backdrop-filter: blur() saturate()` + 半透明 rgba 背景 [$TRAE_REF](https://jishuzhan.net/article/1934134095994466306)
- CSS Grid `gap` 自 Safari 10.1 起支持，无需改动

## 改动清单

### 1. 基础层：CSS 改造

#### 1.1 viewport meta（第 5 行）— 启用安全区
加 `viewport-fit=cover`，否则 `env(safe-area-inset-*)` 在 iPhone 全面屏无效：
```html
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
```

#### 1.2 字体（第 17 行）— SF Pro
显式声明 SF Pro Text/Display：
```css
font-family: -apple-system, BlinkMacSystemFont, "SF Pro Text", "SF Pro Display", "Segoe UI", Roboto, "Helvetica Neue", sans-serif;
```

#### 1.3 新增 CSS 变量（插入到 `*{}` 之前）— iOS 暗色色系
```css
:root {
  --bg-base: #000000;
  --bg-elev: rgba(28,28,30,0.72);
  --bg-elev-2: rgba(44,44,46,0.66);
  --stroke: rgba(255,255,255,0.10);
  --text: #f2f2f7;
  --text-2: #98989f;
  --ios-blue: #0a84ff;
  --ios-green: #30d158;
  --ios-red: #ff453a;
  --ios-orange: #ff9f0a;
  --ios-purple: #bf5af2;
  --glass-blur: blur(20px) saturate(180%);
  --radius: 14px;
}
```
说明：`.btn-primary` 由 `#2563eb` 切到 `--ios-blue`；`.btn-danger` 切到 `--ios-red`；计时器 `running` 切 `--ios-green`、`finished` 切 `--ios-red`。

#### 1.4 玻璃材质类（新增）— 统一应用到卡片/弹窗/头部
```css
.glass {
  background: var(--bg-elev);
  -webkit-backdrop-filter: var(--glass-blur);
  backdrop-filter: var(--glass-blur);
  border: 1px solid var(--stroke);
}
```
应用到：`.header`、`.stage-card`、`.program-item`、`.edit-panel`、`.modal-box`、`.conn-status`、`.tab-btn`、`.icon-btn` 等。每个选择器把原 `background:#1c2029` 替换为引用 `.glass` 或直接内联上述三行。`-webkit-backdrop-filter` 必须写在 `backdrop-filter` 前，Safari 14 仅识别带前缀的。

#### 1.5 flexbox `gap` → margin 回退（共约 18 处）
grid 的 `gap`（`.stage-cards`、`.main-layout`）保留不动。flex 的 `gap` 全部替换：

| 选择器 | 原 gap | 回退写法 |
|---|---|---|
| `.conn-status` | 6px | `.conn-status>*+*{margin-left:6px;}` |
| `.header` | 16px(wrap) | 半边距：`margin:-8px` + `.header>*{margin:8px;}` |
| `.header-left` | 10px | `>*+*{margin-left:10px;}` |
| `.header-right` | 8px | `>*+*{margin-left:8px;}` |
| `.panel-header` | 8px(wrap) | 半边距 `margin:-4px` + 子项 `margin:4px` |
| `.program-list` | 8px(列) | 子项 `margin-bottom:8px;` + `:last-child{margin-bottom:0}` |
| `.performance-view` | 20px(列) | 子块 `margin-bottom:20px;` + `:last-child{margin-bottom:0}` |
| `.stage-mics` | 6px(wrap) | 半边距 `margin:-3px` + `.mic-tag{margin:3px;}` |
| `.timer-controls` | 10px | `>*+*{margin-left:10px;}` |
| `.modal-actions` | 10px(wrap) | 半边距 `margin:-5px` + 子项 `margin:5px` |
| `.tab-bar` | 8px | `.tab-btn{margin-right:8px;}` + `:last-child{margin-right:0}` |
| `.batch-create-bar` | 10px(wrap) | 半边距 `margin:-5px` + 子项 `margin:5px` |
| `.channel-list-wrap` | 8px(列) | 子项 `margin-bottom:8px;` |
| `.channel-row` | 8px(wrap) | 半边距 `margin:-4px` + 子项 `margin:4px` |
| `.channel-check-wrap` | 8px(wrap) | 半边距 `margin:-4px` + 子项 `margin:4px` |
| `.edit-actions` | 8px(wrap) | 半边距 `margin:-4px` + 子项 `margin:4px` |
| 内联 `gap:8px`（第1091行） | 8px | 改用类 `.prog-head`：`>*+*{margin-left:8px;}` |

半边距法（`margin:-X/2` + 子项 `margin:X/2`）在 flex-wrap 下正确模拟 gap，Safari 14 完全支持。

#### 1.6 `inset:0` → 展开式（第 208 行 `.modal`）
```css
top:0; right:0; bottom:0; left:0;
```

#### 1.7 触控目标 ≥44px（新增规则）
```css
.icon-btn { width:44px; height:44px; border-radius:10px; font-size:18px; }
.btn { min-height:44px; padding:11px 18px; }
.btn-sm { min-height:44px; padding:9px 14px; }
.tab-btn { min-height:44px; }
.channel-check-btn { min-height:44px; }
.channel-del-btn { min-height:44px; }
.mic-tag { min-height:32px; display:inline-flex; align-items:center; padding:6px 10px; }
```

#### 1.8 安全区内边距（新增）
```css
.header {
  padding-top: calc(14px + env(safe-area-inset-top));
  padding-left: calc(20px + env(safe-area-inset-left));
  padding-right: calc(20px + env(safe-area-inset-right));
}
.advance-section { padding-bottom: calc(16px + env(safe-area-inset-bottom)); }
.modal-box {
  margin-left: env(safe-area-inset-left);
  margin-right: env(safe-area-inset-right);
}
```

#### 1.9 响应式断点（替换单一 768px 媒体查询）
```css
@media (max-width:1024px) { .main-layout { grid-template-columns: 300px 1fr; } }
@media (max-width:900px) {
  .main-layout { grid-template-columns: 1fr; }
  .stage-cards { grid-template-columns: 1fr 1fr; }
}
@media (max-width:768px) {
  .header { padding:10px 12px; }
  .show-name { font-size:18px; }
  .timer-display { font-size:56px; }
  .stage-cards { grid-template-columns: 1fr; }
  .channel-notes-input { width:100%; }
}
@media (max-width:480px) {
  .timer-display { font-size:44px; }
  .stage-program-name { font-size:20px; }
  .modal-box { width:min(96%,420px); }
}
@media (orientation:landscape) and (max-height:480px) {
  .timer-display { font-size:40px; margin:6px 0; }
}
```

#### 1.10 通道类型彩色标签 CSS（新增）
```css
.ch-tag-mic { background: rgba(10,132,255,0.22); color:#7dbcff; border:1px solid rgba(10,132,255,0.45); }
.ch-tag-line { background: rgba(48,209,88,0.20); color:#7fe0a0; border:1px solid rgba(48,209,88,0.42); }
.ch-tag-custom { background: rgba(255,159,10,0.20); color:#ffbf6b; border:1px solid rgba(255,159,10,0.45); }
```
移除 `.mic-tag` 原 `background:#2563eb`，保留尺寸/圆角基础样式。

#### 1.11 节目详情弹窗 CSS（新增）
```css
.detail-row { display:flex; flex-direction:column; margin-bottom:14px; }
.detail-row .card-label { margin-bottom:4px; }
```

### 2. HTML 结构改动

#### 2.1 合并音乐字段
- **第 585–588 行**（编辑面板的"音乐播放节点"整块）删除，保留 `#edit-musiccue`，label 改为"音乐播放节点 / 提示 Cue"
- **第 624–627 行**（添加节目弹窗的"音乐播放节点"整块）删除，保留 `#add-musiccue`
- **第 525 行** `id="current-musicnode"` → `id="current-music"`
- **第 534 行** `id="next-musicnode"` → `id="next-music"`

#### 2.2 新增节目详情弹窗（插入到 `#modal-add` 之后）
```html
<div id="modal-program-detail" class="modal hidden">
  <div class="modal-box glass">
    <div class="modal-header-row">
      <h3 id="detail-title">节目详情</h3>
      <button class="icon-btn" onclick="closeModal('modal-program-detail')">✕</button>
    </div>
    <div id="detail-body"></div>
    <div class="modal-actions">
      <button class="btn btn-secondary" onclick="closeModal('modal-program-detail')">关闭</button>
      <button class="btn btn-primary" id="detail-set-current-btn">▶ 设为当前节目</button>
    </div>
  </div>
</div>
```

### 3. JavaScript 逻辑改动

#### 3.1 启动流程：立即进入本地模式（第 1457 行 + 671–723 行）
**当前**：末尾 `tryConnectWS()`，内部 3 秒后才降级。

**改为**：
```js
// ---------- 启动 ----------
initLocalMode();   // 立即本地渲染，零延迟
if (location.protocol === 'http:' || location.protocol === 'https:') {
  tryConnectWS(true);  // 仅服务器托管时后台尝试 WS 同步
}
```
并修改 `tryConnectWS`：
- 删除 `setTimeout(()=>{ if(!wsMode) initLocalMode(); }, 3000)` 整块
- 删除 `ws.onclose` 内的 `setTimeout(() => location.reload(), 3000)`，改为静默重连
- `backgroundOnly` 模式下，仅当本地无数据时才接受 `full_state`，避免覆盖未保存的编辑

#### 3.2 mergeState：合并 musicNode+musicCue → musicCue，补全 customType（第 726–746 行）
```js
function mergeMusicField(p) {
  const cue = (p.musicCue || '').trim();
  const node = (p.musicNode || '').trim();
  if (!node) return cue;
  return cue ? `【节点】${node}\n${cue}` : node;
}
function ensureChannel(ch) {
  return { id:ch.id, name:ch.name||'', type:ch.type||'', notes:ch.notes||'', customType:ch.customType||'' };
}
```
`mergeState` 中 programs 映射用 `musicCue: mergeMusicField(p)` 替换原两个字段，不再写 `musicNode`。通道数组用 `ensureChannel` 映射补 `customType`。

幂等性：输出不含 `musicNode`，再次 merge 时 `node` 为空不会重复并入。`loadFromStorage()` 后立即 `saveToStorage()` 一次落盘迁移结果。

#### 3.3 renderGlobalChannelEditor：自定义类型输入框（第 934–1019 行）
每条 `channel-row` 模板中，当 `ch.type === 'custom'` 时追加自定义类型名输入框：
```js
const customInput = ch.type === 'custom'
  ? `<input class="channel-custom-input" placeholder="自定义类型名" value="${escapeAttr(ch.customType||'')}" data-idx="${idx}" data-ctype="mics">`
  : '';
```
事件绑定：
- `select` 用 `onchange`：更新 `type`，若变非 custom 清空 `customType`，调用 `renderGlobalChannelEditor()` 重渲染显隐输入框
- `channel-custom-input` 用 `oninput`：写入 `customType`，**不重渲染**（避免失焦）

新增 CSS：
```css
.channel-custom-input { width:110px; padding:6px 8px; background:#121419; border:1px solid #363c48; border-radius:4px; color:#fff; }
```

#### 3.4 getTypeName：支持 customType（第 1339–1358 行）
```js
function getTypeName(val, type, customType) {
  if (val === 'custom') return (customType && customType.trim()) ? customType : '自定义';
  const micMap = { wireless_headset:'头戴无线麦', wireless_hand:'无线手持麦', podium:'讲台麦',
                   wired:'有线话筒', host:'主持人话筒', guest:'嘉宾话筒' };
  const lineMap = { stereo_line:'立体声线路', mono_line:'单声道线路', drum:'电子鼓',
                    keyboard:'键盘', guitar:'吉他' };
  return type === 'mic' ? (micMap[val]||val) : (lineMap[val]||val);
}
```
调用点更新（第 1372、1383、1420、1429 行）：`getTypeName(ch.type, "mic"/"line", ch.customType)`。

#### 3.5 新增 buildChannelIndex 辅助函数
统一构造带分类与类型标签的通道数组：
```js
function buildChannelIndex() {
  const mics = (localState.globalChannels?.mics || []).map(ch => ({ ...ch, baseCat: 'mic' }));
  const lines = (localState.globalChannels?.lines || []).map(ch => ({ ...ch, baseCat: 'line' }));
  return [...mics, ...lines].map(ch => ({
    ...ch,
    category: ch.type === 'custom' ? 'custom' : ch.baseCat,
    typeLabel: getTypeName(ch.type, ch.baseCat, ch.customType)
  }));
}
```

#### 3.6 renderStageView：彩色类型标签 + musicCue（第 1114–1152 行）
```js
function renderChannelTags(wrap, prog, all) {
  wrap.innerHTML = '';
  if (!prog?.useChannels) return;
  all.filter(ch => prog.useChannels.includes(ch.id)).forEach(ch => {
    const span = document.createElement('span');
    span.className = `mic-tag ch-tag-${ch.category}`;
    span.textContent = `${ch.typeLabel} · ${ch.name}`;
    wrap.appendChild(span);
  });
}
```
`renderStageView` 中 `current-musicnode`/`next-musicnode` 改为 `current-music`/`next-music`，显示合并后的 `musicCue`。

#### 3.7 renderProgramList：演出模式开详情弹窗 + 单行 musicCue（第 1079–1111 行）
- 第 1099–1100 行两行合并为单行：`${prog.musicCue ? '<div ...>🎵 ${escapeHtml(prog.musicCue)}</div>' : ''}`
- onclick 分支：演出模式 `openProgramDetail(idx)` 替代 `sendMsg({type:"set_current"})`

#### 3.8 新增 openProgramDetail 函数
```js
let detailIndex = null;
function openProgramDetail(idx) {
  detailIndex = idx;
  const p = localState.programs[idx];
  if (!p) return;
  const all = buildChannelIndex();
  const used = all.filter(ch => p.useChannels?.includes(ch.id));
  const tagsHtml = used.map(ch => `<span class="mic-tag ch-tag-${ch.category}">${escapeHtml(ch.typeLabel)} · ${escapeHtml(ch.name)}</span>`).join('');
  document.getElementById('detail-title').textContent = `${idx+1}. ${p.name}`;
  document.getElementById('detail-body').innerHTML = `
    <div class="detail-row"><span class="card-label">时长</span><span>${p.duration>0?formatSec(p.duration):'不计时'}</span></div>
    <div class="detail-row"><span class="card-label">通道</span><div class="stage-mics">${tagsHtml||'<span style="color:#98989f">无</span>'}</div></div>
    <div class="detail-row"><span class="card-label">音乐节点/提示</span><span style="color:#ffc857;white-space:pre-wrap">${escapeHtml(p.musicCue||'无')}</span></div>
    <div class="detail-row"><span class="card-label">舞台备注</span><span style="white-space:pre-wrap">${escapeHtml(p.notes||'无')}</span></div>
    <div class="detail-row"><span class="card-label">状态</span><span>${p.completed?'✅ 已完成':'⏳ 未完成'}</span></div>
  `;
  document.getElementById('detail-set-current-btn').onclick = () => {
    sendMsg({ type: 'set_current', index: detailIndex });
    closeModal('modal-program-detail');
  };
  document.getElementById('modal-program-detail').classList.remove('hidden');
}
```

#### 3.9 编辑/新建节目函数：移除 musicNode（第 1232–1332 行）
- `openAddProgram`：删除 `add-musicnode` 赋值
- `openEditProgram`：删除 `edit-musicnode` 赋值
- `saveProgram`：删除 `musicNode` 读取与对象字段
- `confirmAddProgram`：删除 `musicNode` 读取与对象字段

#### 3.10 renderProgramChannelSelector 复用 buildChannelIndex（第 1155–1188 行）
勾选按钮显示 `typeLabel · name` 并按分类着色，与舞台视图一致。

## 假设与决策

1. 合并后的音乐字段命名为 `musicCue`，标签为"音乐播放节点 / 提示 Cue"
2. 自定义类型名为空时，`getTypeName` 返回"自定义"兜底
3. 演出模式点击节目卡片打开详情弹窗，弹窗内含"设为当前节目"按钮
4. 通道标签颜色：话筒=蓝色、线路=绿色、自定义=橙色
5. 旧数据通过 `mergeState` 自动迁移，无需用户手动操作
6. 离线双击场景立即进入本地模式，WS 仅作为 http(s) 托管时的后台增强
7. CDN 库（html2pdf/file-saver/SortableJS）保持不变，QRCode 已内联可离线使用
8. flexbox gap 一律替换为 margin 方案，grid gap 保留不动

## 验证步骤

1. **flex gap**：全局搜索 `gap:` 应仅剩 grid 用法（`.main-layout`、`.stage-cards`）
2. **inset**：搜索 `inset:` 应为 0 结果
3. **backdrop-filter**：每个使用处都成对出现 `-webkit-backdrop-filter` 与 `backdrop-filter`
4. **file:// 启动**：双击 HTML，状态指示立即显示"本地模式"，无 3 秒等待
5. **数据迁移**：用含旧 `musicNode` 的 localStorage 数据加载后，节目只显示一个音乐字段且包含旧节点内容；刷新后 localStorage 不再有 `musicNode` 键
6. **自定义类型**：全局通道编辑器选择"自定义"→ 出现输入框；输入后保存，舞台视图标签显示"自定义名 · 通道名"且橙色
7. **演出模式详情**：切到演出模式，点击节目 → 弹出详情弹窗 → 点"设为当前节目"→ 当前节目卡切换
8. **触控**：iPhone Safari 下所有按钮 ≥44px，顶部/底部不被刘海/Home 条遮挡
9. **iPad**：竖屏 1024px 下布局正常；横屏无横向滚动
10. **Mac Safari 14**：玻璃效果正常显示，无布局塌陷

## 风险与注意事项

- **WS 后台增强覆盖风险**：`backgroundOnly` 模式下仅当本地 `programs` 为空时才接受 `full_state`
- **自定义输入框失焦**：`select.onchange` 触发重渲染时焦点在 select 上（已 change 完成），不影响自定义输入；但 `channel-custom-input` 的 `oninput` 绝不能触发重渲染
- **半边距法副作用**：`margin:-X/2` 使容器外溢，需在验证阶段目视检查无错位
- **iOS 暗色玻璃性能**：`blur(20px) saturate(180%)` 在老旧 iPad 上可能掉帧；可对长列表容器降低 blur 或不加玻璃
