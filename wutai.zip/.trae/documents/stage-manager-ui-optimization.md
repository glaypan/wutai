# 舞台流程表 UI 优化计划

## 概述

对 `/workspace/舞台流程表.html` 单文件应用进行 5 项优化：合并音乐字段、自定义类型输入、通道标签显示类型、演出模式详情弹窗、整体 UI 美化。所有改动集中在单文件内，保持向后兼容。

## 当前状态分析

- 单 HTML 文件（1460 行），内联 CSS/JS/QRCode 库
- 数据结构：`globalChannels.mics/lines`（含 id/name/type/notes），`programs`（含 useChannels 引用通道 id）
- 当前有两个音乐字段：`musicNode`（精准切入节点）和 `musicCue`（简易提示），造成 UI 冗余
- 通道类型下拉框选"自定义"后无法填写自定义名称
- 演出模式舞台卡片通道标签只显示通道名，不显示类型
- 演出模式点击节目只能切换当前节目，无法查看详情
- `mergeState()` 负责旧数据兼容迁移

## 改动清单

### 1. 数据结构变更

#### 1.1 合并音乐字段
- 删除 `musicNode` 字段，保留 `musicCue` 作为唯一音乐字段
- `mergeState()` 中迁移逻辑：若旧数据有 `musicNode`，合并到 `musicCue`（格式：`节点：xxx\n提示：xxx`）
- 新节目不再生成 `musicNode` 字段

#### 1.2 通道对象新增字段
- `customType: ""` — 仅 `type === "custom"` 时使用，存储自定义类型名
- `category: "mic" | "line"` — 在 mergeState 中注入，方便 getTypeName 判断

### 2. HTML 结构变更

#### 2.1 编辑面板（约第 585-593 行）
删除 `edit-musicnode` 和 `edit-musiccue` 两个 textarea，替换为单个：
```html
<div class="form-group">
  <label>🎵 音乐播放提示 / Music Cue（含切入节点）</label>
  <textarea id="edit-musiccue" class="text-input textarea"
    placeholder="如：前奏8小节后进人声；副歌第2段起灯光；末尾淡出"></textarea>
</div>
```

#### 2.2 添加节目弹窗（约第 624-631 行）
同样删除两个 textarea，替换为单个 `add-musiccue`。

#### 2.3 演出视图舞台卡片（约第 525、534 行）
- `current-musicnode` → `current-music`
- `next-musicnode` → `next-music`

#### 2.4 新增节目详情弹窗（在 modal-add 之后）
```html
<div id="modal-program-detail" class="modal hidden">
  <div class="modal-box modal-wide">
    <div class="modal-header-row">
      <h3 id="detail-title">节目详情</h3>
      <button class="icon-btn" onclick="closeModal('modal-program-detail')">✕</button>
    </div>
    <div id="detail-body" class="detail-body"></div>
    <div class="modal-actions">
      <button class="btn btn-secondary" onclick="closeModal('modal-program-detail')">关闭</button>
      <button class="btn btn-primary" id="detail-set-current-btn">▶ 设为当前节目</button>
    </div>
  </div>
</div>
```

### 3. CSS 新增样式（追加到 `</style>` 前）

```css
/* 自定义类型输入框 */
.channel-custom-input {
  width: 110px; padding: 6px 8px;
  background: #121419; border: 1px solid #363c48;
  border-radius: 4px; color: #fff;
}

/* 通道标签带类型 */
.mic-tag { display: inline-flex; align-items: center; gap: 4px; }
.mic-tag .tag-type {
  font-size: 11px; opacity: 0.75;
  padding-left: 4px; border-left: 1px solid rgba(255,255,255,0.3);
}
.mic-tag.mic { background: #2563eb; }
.mic-tag.line { background: #7c3aed; }
.mic-tag.custom { background: #ea580c; }

/* 节目详情弹窗 */
.detail-body { display:flex; flex-direction:column; gap:14px; }
.detail-section { background:#121419; border:1px solid #272c36;
                   border-radius:8px; padding:12px 14px; }
.detail-section-label { font-size:12px; color:#94a3b8; margin-bottom:6px; }
.detail-section-value { font-size:15px; color:#eee; line-height:1.6;
                         white-space:pre-wrap; word-break:break-word; }
.detail-channels { display:flex; flex-wrap:wrap; gap:6px; }
.detail-duration { font-size:18px; font-weight:600; color:#22c55e; }

/* 节目卡片详情按钮 */
.prog-action-row { display:flex; gap:6px; margin-top:6px; justify-content:flex-end; }
.prog-detail-btn { padding: 4px 10px; font-size:12px;
  background:#272c36; color:#cbd5e1; border:none; border-radius:4px; cursor:pointer; }

/* 通用美化 */
.stage-card { transition: box-shadow 0.2s; }
.stage-card:hover { box-shadow: 0 4px 16px rgba(0,0,0,0.3); }
.music-cue-display {
  background: rgba(255,200,87,0.08);
  border-left: 3px solid #ffc857;
  padding: 8px 12px; border-radius: 4px;
  white-space: pre-wrap; line-height: 1.5;
}
.stage-notes {
  background: rgba(148,163,184,0.08);
  padding: 8px 12px; border-radius: 4px; line-height: 1.5;
}
.btn { transition: background 0.15s, transform 0.1s; }
.btn:active { transform: scale(0.97); }
.btn-primary:hover { background: #1d4ed8; }
.timer-display { text-shadow: 0 0 24px currentColor; }
```

### 4. JS 函数修改

#### 4.1 `mergeState()` — 数据迁移
- 合并 `musicNode` + `musicCue` → `musicCue`
- 为通道补 `customType: ""` 和 `category: "mic"|"line"` 字段

#### 4.2 `getTypeName(ch)` — 重构签名
改为接收通道对象（而非 val + type），通过 `ch.category` 判断 mic/line，`type === "custom"` 时返回 `customType || "自定义"`。更新所有调用点。

#### 4.3 `renderGlobalChannelEditor()` — 自定义类型输入
- 每行增加 `.channel-custom-input`，`type === "custom"` 时显示，否则隐藏
- `.channel-type-select` 绑定 `onchange`：切换 custom 时显隐输入框
- `.channel-custom-input` 绑定 `oninput`：实时写入 `ch.customType`

#### 4.4 `renderStageView()` — 通道标签显示类型
- 新增 `buildChannelTag(ch)` 函数，生成带类型信息的标签（名称 + 类型，mic/line/custom 不同颜色）
- `current-musicnode`/`next-musicnode` 改为 `current-music`/`next-music`，显示合并后的 `musicCue`

#### 4.5 `renderProgramList()` — 节目列表
- 合并 musicNode/musicCue 显示为单行
- 演出模式点击节目改为打开详情弹窗（`openProgramDetail(idx)`）
- 演出模式节目卡片末尾增加"详情"按钮

#### 4.6 新增 `openProgramDetail(idx)` — 演出模式详情弹窗
- 展示节目名称、启用通道（带类型标签）、音乐提示、备注、时长
- "设为当前节目"按钮：调用 `sendMsg({type:"set_current"})`，已是当前则禁用

#### 4.7 清理 musicNode 残留
- `openEditProgram`：删除 `edit-musicnode` 赋值
- `saveProgram`：删除 `musicNode` 变量和对象字段
- `openAddProgram`：删除 `add-musicnode` 清空
- `confirmAddProgram`：删除 `musicNode` 变量和对象字段

#### 4.8 导出函数适配
- `getExportHtml()` / `exportCSV()`：`getTypeName(ch.type, "mic")` → `getTypeName(ch)`
- 导出表格可选增加"自定义类型名"列

## 假设与决策

1. 合并后的音乐字段命名为 `musicCue`，标签为"🎵 音乐播放提示 / Music Cue"
2. 自定义类型名为空时，`getTypeName` 返回"自定义"兜底
3. 演出模式点击节目卡片打开详情弹窗，详情弹窗内含"设为当前节目"按钮
4. 通道标签颜色：话筒=蓝色、线路=紫色、自定义=橙色
5. 旧数据通过 `mergeState` 自动迁移，无需用户手动操作

## 验证步骤

1. 打开 HTML 文件，确认旧 localStorage 数据（含 musicNode）能正确迁移为 musicCue
2. 全局通道设置：选择"自定义"后输入框出现，可填写并保存
3. 编辑节目：只有一个音乐字段，保存后演出视图正确显示
4. 演出模式：通道标签显示"名称(类型)"，不同类型颜色不同
5. 演出模式：点击节目卡片或"详情"按钮，弹窗显示完整信息
6. 导出 PDF/CSV：通道类型正确显示（含自定义类型名）
7. 移动端响应式：768px 断点下布局正常
